SMM_LINK_USER=http://127.0.0.1:8000/form/user/

SMM_LINK_TECHER=http://127.0.0.1:8000/form/techer/

CDN_LINK_TECHER=https://atko.tech/MyCrmTest/

SMS_EMAIL=login

SMS_PASSWORD=password

MARKAZLOGOLINK=https://atko.tech/MyCrmTest1/public
