<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruh</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_groups')); ?>">Guruhlar</a></li>
                    <li class="breadcrumb-item active">Guruh</li>
                </ol>
            </nav>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center"><?php echo e($guruh['guruh_name']); ?></h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Dars xonasi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['room_name']); ?></div>
                                <div class="col-6  mt-1"><b>Dars boshlandi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_start']); ?></div>
                                <div class="col-6  mt-1"><b>Dars tugadi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_end']); ?></div>
                                <div class="col-6  mt-1"><b>Darslar vaqti:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_time']); ?></div>
                                <div class="col-6  mt-1"><b>Darslar soni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_count']); ?></div>
                                <div class="col-6  mt-1"><b>Hafta kuni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['hafta_kun']); ?></div>
                                <div class="col-6  mt-1"><b>Guruh davomi:</b></div>
                                <div class="col-6" style="text-align:right;">
                                    <?php if($guruh['next_id']!=='false'): ?>
                                        <a href="<?php echo e(route('meneger_groups_show',$guruh['newGroupID'] )); ?>">Davom ettirilgan: (<?php echo e($guruh['newGroup']); ?>)</a>
                                    <?php else: ?> 
                                        Davom ettirilmagan
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center">Guruh narxi: <?php echo e(number_format($guruh['paymart']['summa'], 0, '.', ' ')); ?> so'm</h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Chegirma:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['paymart']['chegirma'], 0, '.', ' ')); ?> so'm</div>  
                                <div class="col-6  mt-1"><b>Chegirma muddati:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['paymart']['chegirma_time']); ?> kun</div>  
                                <div class="col-6  mt-1"><b>O'qituvchi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer']); ?></div>
                                <?php if($guruh['techer_tulov']==1): ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer_foiz']); ?>%</div>
                                <?php elseif($guruh['techer_tulov']==2): ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                <?php else: ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                    <div class="col-6  mt-1"><b>Ish haqi bonus:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_bonus'], 0, '.', ' ')); ?> so'm</div>
                                <?php endif; ?>
                                <div class="col-4  mt-1"><b>Meneger:</b></div>
                                <div class="col-8" style="text-align:right;"><?php echo e($guruh['meneger']); ?></div>
                                <div class="col-6  mt-1"><b>Guruh ochildi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['created_at']); ?></div>        
                            </div>
                        </div>
                    </div>  
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                <div class="row mt-3">
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100" data-bs-toggle="modal"  data-bs-target="#lessenDays">Dars kunlari</button>
                    </div>
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100" data-bs-toggle="modal"  data-bs-target="#updateUser">Test natijalari</button>
                    </div>
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100" data-bs-toggle="modal" data-bs-target="#createPaymart">Qarzdorlarga sms yuborish</button>
                    </div>
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100"  data-bs-toggle="modal" data-bs-target="#addGroups">Guruhdan talaba o'chirish</button>
                    </div>
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100" data-bs-toggle="modal" data-bs-target="#repetPaymart">Guruh ma`lumotini yangilash</button>
                    </div>
                    <div class="col-lg-4">
                        <button class="btn btn-primary my-1 w-100" data-bs-toggle="modal"  data-bs-target="#endGroups">Talabalar davomati</button>
                    </div>
                    <div class="col-lg-12 text-center">
                        <?php if($guruh['next_id']=='false'): ?>
                            <a class="btn btn-primary my-1 w-50" href="<?php echo e(route('meneger_groups_next_create',$guruh['id'] )); ?>">Guruhni davom ettirish</a>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title w-100 text-center">Guruh talabalari</h5>
                    <div class="table-responsive">
                        <table class="table text-center table-bordered" style="font-size: 12px;">
                        <thead>
                            <tr class="align-items-center">
                            <th>#</th>
                            <th>Talaba</th>
                            <th>Guruhga qo'shildi</th>
                            <th>Meneger</th>
                            <th>Izoh</th>
                            <th>Guruhdan o'chirildi</th>
                            <th>Meneger</th>
                            <th>Izoh</th>
                            <th>Jarima</th>
                            <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $guruh['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td style="text-align:left;"><a href="<?php echo e(route('meneger.all_show',$item['User']['user_id'])); ?>"><?php echo e($item['UserName']); ?></a></td>
                                <td><?php echo e($item['User']['grops_start_data']); ?></td>
                                <td style="text-align:left;"><?php echo e($item['User']['grops_start_comment']); ?></td>
                                <td><?php echo e($item['User']['grops_start_meneger']); ?></td>
                                <td><?php echo e($item['User']['grops_end_data']); ?></td>
                                <td><?php echo e($item['User']['grops_end_meneger']); ?></td>
                                <td style="text-align:left;"><?php echo e($item['User']['grops_end_comment']); ?></td>
                                <td><?php echo e($item['User']['jarima']); ?></td>
                                <td>
                                    <?php if($item['User']['status'] == 'true'): ?>
                                        <b class="text-success p-0 m-0">Aktiv<b>
                                    <?php else: ?> 
                                        <b class="text-danger p-0 m-0">O'chirildi<b>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div> 
            <!--Qarzdorlarga SMS +++ --> 
            <div class="modal fade" id="createPaymart" tabindex="-1">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title w-100 text-center">Qarzdorlarga SMS yuborish</h5>
                        </div>
                        <div class="modal-body m-0 p-1" style="padding:3px">
                            <form action="" method="post" class="m-0 p-0">
                                <div class="row">
                                    <div class="col-6">
                                        <button type="button" class="btn btn-danger w-100 m-0" data-bs-dismiss="modal" aria-label="Close">Bekor qilish</button>
                                    </div>
                                    <div class="col-6">
                                        <button type="submit" class="btn btn-primary w-100 m-0">Tasdiqlash</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--Guruhni taxrirlash-->
            <div class="modal fade" id="repetPaymart" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Guruhni taxrirlash</h5>
                        </div>
                        <div class="modal-body">
                            <form action="" method="post">
                                <label for="" class="my-2">Guruh nomi</label>
                                <input type="text" required class="form-control">
                                <label for="" class="my-2">O'qituvchi</label>
                                <select name="" required class="form-select">
                                    <option value="">Tanlang...</option>
                                </select>
                                <label for="" class="my-2">O'qituvchiga to'lov turi</label>
                                <select name="" required class="form-select">
                                    <option value="">Tanlang...</option>
                                </select>
                                <label for="" class="my-2">To'lov foizi</label>
                                <input type="text" required class="form-control">
                                <label for="" class="my-2">O'qituvchiga to'lov</label>
                                <input type="text" required class="form-control">
                                <label for="" class="my-2">O'qituvchiga bonus</label>
                                <input type="text" required class="form-control">
                                <label for="" class="my-2">Guruh uchun kurs</label>
                                <select name="" required class="form-select">
                                    <option value="">Tanlang...</option>
                                </select>
                                <label for="" class="my-2">Guruh narxi</label>
                                <select name="" required class="form-select">
                                    <option value="">Tanlang...</option>
                                </select>
                                <div class="w-100 text-center mt-2">
                                    <button class="btn btn-primary w-50">O'zgarishlarni saqlash</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--Talabani o'chirish +++++ -->
            <div class="modal fade" id="addGroups" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title w-100 text-center">Guruh talabasin o'chirish</h5>
                        </div>
                        <div class="modal-body">
                        <form action="<?php echo e(route('meneger.user_delete_group')); ?>" method="post">
                            <?php echo csrf_field(); ?> 
                            <input type="hidden" name="guruh_id" value="<?php echo e($guruh['id']); ?>">
                            <input type="hidden" name="guruh_price" value="<?php echo e($guruh['paymart']['summa']); ?>">
                            <label for="user_id" class="mb-2">Guruhdan o'chiladigan talabani tanlang</label>
                            <select name="user_id" required class="form-select">
                                <option value="">Tanlang...</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $guruh['users_active']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($item['user_id']); ?>"><?php echo e($item['name']); ?> Balansi: <?php echo e(number_format($item['balans'], 0, '.', ' ')); ?> so'm</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                            </select>
                            <label for="jarima" class="mt-2 mb-2">Jarima summasi <i>(Maksima jarima summasi: <?php echo e(number_format($guruh['paymart']['summa'], 0, '.', ' ')); ?> so'm)</i></label>
                            <input type="number" name="jarima" max=<?php echo e($guruh['paymart']['summa']); ?> required class="form-control">
                            <label for="grops_end_comment" class="mt-2 mb-2">Guruhdan o'chirish sababi</label>
                            <textarea type="text" name="grops_end_comment" required class="form-control"></textarea>
                            <div class="row mt-2">
                            <div class="col-6">
                                <button type="button" class="btn btn-danger w-100" data-bs-dismiss="modal" aria-label="Close">Bekor qilish</button>
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-primary w-100">O'chirish</button>
                            </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--Davomat-->
            <div class="modal fade" id="endGroups" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title">Davomat</h5>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <table class="table text-center table-bordered" style="font-size: 12px;">
                                    <thead>
                                        <tr class="align-items-center">
                                        <th>#</th>
                                        <th>Talaba</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        <th>12.07.2024</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td>1</td>
                                        <td>Elshod Musurmonov</td>
                                        <td class="bg-danger text-white"><i class="bi bi-shield-x" title="Davomat olinmagan"></i></td>
                                        <td class="bg-warning text-white"><i class="bi bi-shield-minus" title="Darsga qatnashmagan"></i></td>
                                        <td class="bg-success text-white"><i class="bi bi-shield-plus" title="Darsga qatnashgan"></i></td>
                                        <td class="bg-info text-white"><i class="bi bi-shield-lock" title="Davomat kutilmoqda"></i></td>
                                        <td class="bg-danger text-white"><i class="bi bi-shield-x" title="Davomat olinmagan"></i></td>
                                        <td class="bg-warning text-white"><i class="bi bi-shield-minus" title="Darsga qatnashmagan"></i></td>
                                        <td class="bg-success text-white"><i class="bi bi-shield-plus" title="Darsga qatnashgan"></i></td>
                                        <td class="bg-info text-white"><i class="bi bi-shield-lock" title="Davomat kutilmoqda"></i></td>
                                        <td class="bg-danger text-white"><i class="bi bi-shield-x" title="Davomat olinmagan"></i></td>
                                        <td class="bg-warning text-white"><i class="bi bi-shield-minus" title="Darsga qatnashmagan"></i></td>
                                        <td class="bg-success text-white"><i class="bi bi-shield-plus" title="Darsga qatnashgan"></i></td>
                                        <td class="bg-info text-white"><i class="bi bi-shield-lock" title="Davomat kutilmoqda"></i></td>
                                        <td class="bg-danger text-white"><i class="bi bi-shield-x" title="Davomat olinmagan"></i></td>
                                        <td class="bg-warning text-white"><i class="bi bi-shield-minus" title="Darsga qatnashmagan"></i></td>
                                        <td class="bg-success text-white"><i class="bi bi-shield-plus" title="Darsga qatnashgan"></i></td>
                                        <td class="bg-info text-white"><i class="bi bi-shield-lock" title="Davomat kutilmoqda"></i></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Dars kunlari-->
            <div class="modal fade" id="lessenDays" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Dars kunlari</h5>
                        </div>
                        <div class="modal-body">
                            <ul class="list-group">
                                <?php $__currentLoopData = $guruh['dars_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <?php echo e($loop->index+1); ?>-dars
                                        <span class="badge bg-primary rounded-pill"><?php echo e($item['data']); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!--Test narijalari-->
            <div class="modal fade" id="updateUser" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Test natijalari</h5>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <table class="table text-center table-bordered" style="font-size: 12px;">
                                <thead>
                                    <tr class="align-items-center">
                                    <th>#</th>
                                    <th>Talaba</th>
                                    <th>Urinishlar soni</th>
                                    <th>To'g'ri javob</th>
                                    <th>Ball</th>
                                    <th>Birinchi urinish vaqti</th>
                                    <th>Oxirgi urinish vaqti</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $UserTestCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($item['user']); ?></td>
                                        <td><?php echo e($item['urinish']); ?></td>
                                        <td><?php echo e($item['count']); ?></td>
                                        <td><?php echo e($item['ball']); ?></td>
                                        <td><?php echo e($item['created_at']); ?></td>
                                        <td><?php echo e($item['updated_at']); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan=7 class="text-center">Test yechgan talabalar mavjud emas.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/group_show.blade.php ENDPATH**/ ?>