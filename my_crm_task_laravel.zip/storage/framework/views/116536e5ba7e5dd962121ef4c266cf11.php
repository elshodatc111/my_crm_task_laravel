<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

<div class="pagetitle">
  <h1>Hodimlar</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
      <li class="breadcrumb-item active">Hodimlar</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">
  <div class="row mb-2">
    <div class="col-lg-3 mt-2 mt-lg-0">
      <a href="<?php echo e(route('meneger.hodim')); ?>" class="btn btn-primary w-100">Hodimlar</a>
    </div>
    <div class="col-lg-3 mt-2 mt-lg-0">
      <a href="<?php echo e(route('meneger.hodim_create')); ?>" class="btn btn-secondary w-100">Yangi hodim</a>
    </div>
    <div class="col-lg-3 mt-2 mt-lg-0">
      <a href="<?php echo e(route('meneger.techer')); ?>" class="btn btn-secondary w-100">O'qituvchilar</a>
    </div>
    <div class="col-lg-3 mt-2 mt-lg-0">
      <a href="<?php echo e(route('meneger.techer_create')); ?>" class="btn btn-secondary w-100">Yangi o'qituvchi</a>
    </div>
  </div>

  <?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php elseif(Session::has('error')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>


  <div class="card">
    <div class="card-body">
      <h5 class="card-title w-100 text-center">Hodimlar</h5>
      <div class="table-responsive">
        <table class="table text-center table-bordered" style="font-size: 12px;">
          <thead>
            <tr class="align-items-center">
              <th>#</th>
              <th>Hodim</th>
              <th>Login</th>
              <th>Telefon</th>
              <th>Lavozim</th>
              <th>Faoliyati</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->index+1); ?></td>
              <td style="text-align:left;">
                <a href="<?php echo e(route('meneger.hodim_show', $item['id'])); ?>"><b class="m-0 p-0"><?php echo e($item['name']); ?></b></a>
              </td>
              <td style="text-align:left"><?php echo e($item['email']); ?></td>
              <td><?php echo e($item['phone1']); ?></td>
              <td>
                <?php if($item['role_id']==2): ?>
                  Drektor
                <?php elseif($item['role_id']==3): ?>
                  Admin
                <?php else: ?>
                  Meneger
                <?php endif; ?>
              </td>
              <td>
                <?php if($item['status']=='true'): ?>
                <span class="bg-success p-1 text-white">Aktiv</span>
                <?php else: ?>
                <span class="bg-danger p-1 text-white">Bloklangan</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if($item['status']=='true'): ?>
                  <form action="<?php echo e(route('meneger.hodim_unlock')); ?>" method="post" class="m-0">
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                    <button type="submit" class="btn btn-danger p-1 m-0" title="Bloklash"><i class="bi bi-lock"></i></button>
                  </form>
                <?php else: ?>
                  <form action="<?php echo e(route('meneger.hodim_unlock')); ?>" method="post" class="m-0">
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                    <button type="submit" class="btn btn-danger p-1 m-0" title="Aktivlashtirish"><i class="bi bi-unlock"></i></button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td class="text-center">Hodimlar vajud emas</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

</main>

<footer id="footer" class="footer">
<div class="copyright">
  &copy; <strong><span>CodeStart</span></strong>. development center
</div>
<div class="credits">
  Qarshi 2024
</div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/hodim/hodim.blade.php ENDPATH**/ ?>