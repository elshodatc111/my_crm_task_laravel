<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>




  
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Yangi tashrif</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.all_tashrif')); ?>">Bosh sahifa</a></li>
          <li class="breadcrumb-item active">Yangi tashrif</li>
        </ol>
      </nav>
    </div>

    <section class="section dashboard"> 

      <div class="row mb-2">
        <div class="col-lg-3 mt-lg-0 mt-3">
          <a href="<?php echo e(route('meneger.all_tashrif')); ?>" class="btn btn-secondary w-100">Tashriflar</a>
        </div>
        <div class="col-lg-3 mt-lg-0 mt-3">
          <a href="<?php echo e(route('meneger.all_debet')); ?>" class="btn btn-secondary w-100">Qarzdorlar</a>
        </div>
        <div class="col-lg-3 mt-lg-0 mt-3">
          <a href="<?php echo e(route('dars_jadval')); ?>" class="btn btn-secondary w-100">Dars jadvali</a>
        </div>
        <div class="col-lg-3 mt-lg-0 mt-3">
          <a href="<?php echo e(route('meneger.all_create')); ?>" class="btn btn-primary w-100">Yangi tashrif</a>
        </div>
      </div>

      
      <div class="card">
        <div class="card-body">
          <h5 class="card-title w-100 text-center">Yangi tashrif</h5>
          <form action="<?php echo e(route('meneger.all_create_story')); ?>" method="post">
            <?php echo csrf_field(); ?> 
            <div class="row">
              <div class="col-lg-6">
                <label for="name" class="mb-1">FIO</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" required class="form-control">
                <label for="phone1" class="mb-1 mt-1">Telefon raqam</label>
                <input type="text"  name="phone1" value="<?php echo e(old('phone1')); ?>" required class="form-control phone">
                <?php $__errorArgs = ['phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger w-100" style="font-size:10px;">Telefon raqam oldin ro'yhatga olingan.</span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="phone2" class="mb-1 mt-1 w-100">Qo'shimcha telefon raqam</label>
                <input type="text" name="phone2" value="<?php echo e(old('phone2')); ?>" required class="form-control phone">
                <label for="addres" class="mb-1 mt-1">Yashash manzili</label>
                <select name="addres" required class="form-select">
                  <option value="">Tablang...</option>
                  <?php $__currentLoopData = $MarkazAddres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item['addres']); ?>"><?php echo e($item['addres']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-lg-6">
                <label for="tkun" class="mt-1 mt-lg-0 mb-1">Talaba tug'ilgan kuni</label>
                <input type="date" name="tkun" value="<?php echo e(old('tkun')); ?>" required class="form-control">
                <?php $__errorArgs = ['tkun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger w-100" style="font-size:10px;">Yosh chagarasi (7 yoshdan 65 yoshgacha).</span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="about" class="mb-1 mt-1 w-100">Talaba haqida</label>
                <textarea name="about" rows="4" required class="form-control"><?php echo e(old('about')); ?></textarea>
                <label for="smm" class="mb-1 mt-1">Biz haqimizda</label>
                <select name="smm" required class="form-select">
                  <option value="">Tanlang...</option>
                  <?php $__currentLoopData = $MarkazSmm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item['smm']); ?>"><?php echo e($item['smm']); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-12 text-center mt-4">
                <button type="submit" class="btn btn-primary w-50">Tashrifni saqlash</button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </section>
  </main>
  
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; <strong><span>CodeStart</span></strong>. development center
    </div>
    <div class="credits">
      Qarshi 2024
    </div>
  </footer>
  

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/students/create.blade.php ENDPATH**/ ?>