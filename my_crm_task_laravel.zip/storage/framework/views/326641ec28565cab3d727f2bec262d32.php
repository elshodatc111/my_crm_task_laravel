<?php $__env->startSection('title', 'Hisobot'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item active">Hisobot</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row mb-2">
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_student')); ?>" class="btn btn-secondary w-100">Talabalar</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_hodim')); ?>" class="btn btn-secondary w-100">Hodimlar</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_moliya')); ?>" class="btn btn-primary w-100">Moliya</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_active_user')); ?>" class="btn btn-secondary w-100">Aktiv talabalar</a>
            </div>
        </div>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h2 class="card-title w-100 text-center">Moliya</h2>
                <form action="<?php echo e(route('report_moliya_search')); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    <div class="row">
                        <div class="col-6">
                            <select name="type" required class="form-select">
                                <option value="">Tanlang</option>
                                <option value="allPaymarty">Barcha to'lovlar</option>
                                <option value="kassadanChiqim">Kassadan tasdiqlangan chiqimlar</option>
                                <option value="KassadanXarajat">Kassadan tasdiqlangan xarajatlar</option>
                                <option value="KassagaQaytarIshHaqi">Kassaga qaytarilgan ish haqi</option>
                                <option value="KassadanBalansgaIshHaqi">Kassadan balansga qaytarilgan ish haqi</option>
                                <option value="KassagaQaytar">Balansdan kassaga qaytarilganlar</option>
                                <option value="BalansdanXarajat">Balansdan xarajatlar</option>
                                <option value="BalansdanChiqim">Balansdan chiqimlar</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h2 class="w-100 text-center card-title">
                    <?php if($type=='allPaymarty'): ?>
                        Barcha to'lovlar
                    <?php elseif($type=='kassadanChiqim'): ?>
                        Kassadan tasdiqlangan chiqimlar
                    <?php elseif($type=='KassadanXarajat'): ?>
                        Kassadan tasdiqlangan xarajatlar
                    <?php elseif($type=='KassagaQaytarIshHaqi'): ?>
                        Kassaga qaytarilgan ish haqi
                    <?php elseif($type=='KassadanBalansgaIshHaqi'): ?>
                        Kassadan balansga qaytarilgan ish haqi
                    <?php elseif($type=='KassagaQaytar'): ?>
                        Balansdan kassaga qaytarilganlar
                    <?php elseif($type=='BalansdanXarajat'): ?>
                        Balansdan xarajarlar
                    <?php elseif($type=='BalansdanChiqim'): ?>
                        Balansdan chiqimlar
                    <?php endif; ?>
                </h2>
                <div class="w-100" style="text-align:right">
                    <button id="downloadExcel" class="btn btn-secondary" title="print excel"><i class="bi bi-printer"></i></button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="myTable" style="font-size:14px;border:1px solid #A5C8FD">
                        <head>
                        <?php if($type=='allPaymarty'): ?>
                            <tr>
                                <td>#</td>
                                <td>Student_id</td>
                                <td>Student</td>
                                <td>To'lov summasi</td>
                                <td>To'lov turi</td>
                                <td>Guruh ID</td>
                                <td>To'lov haqida</td>
                                <td>Meneger</td>
                                <td>To'lov vaqti</td>
                            </tr>
                        <?php elseif($type=='kassadanChiqim'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Chiqim vaqti</td>
                                <td>Meneger</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='KassadanXarajat'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Chiqim vaqti</td>
                                <td>Meneger</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='KassagaQaytarIshHaqi'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='KassadanBalansgaIshHaqi'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='KassagaQaytar'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='BalansdanXarajat'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php elseif($type=='BalansdanChiqim'): ?>
                            <tr>
                                <td>#</td>
                                <td>Hodisa</td>
                                <td>Summa</td>
                                <td>Chiqim Turi</td>
                                <td>Chiqim haqida</td>
                                <td>Administrator</td>
                                <td>Tasdiqlandi</td>
                            </tr>
                        <?php endif; ?>
                        </head>
                        <body>
                        <?php if($type=='allPaymarty'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['user_id']); ?></td>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['tulov_type']); ?></td>
                                    <td><?php echo e($item['guruh']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>To'lovlar mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='kassadanChiqim'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>Kassadan chiqimlar mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='KassadanXarajat'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>Kassadan xarajatlar mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='KassagaQaytarIshHaqi'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>Balansdan kassaga qaytarilgan ish haqi mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='KassadanBalansgaIshHaqi'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>Kassadan balansga qaytarilhan ish haqi mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='KassagaQaytar'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=9>Kassaga qaytarilganlar mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='BalansdanXarajat'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=7>Balansdan xarjatlar mavjus emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='BalansdanChiqim'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['hodisa']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['administrator']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=7>Balansdan chiqimlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php endif; ?>
                        </body>
                    </table>
                </div>
            </div>
        </div>
  
    </section>

</main>

<footer id="footer" class="footer">
    <div class="copyright">
        &copy; <strong><span>CodeStart</span></strong>. development center
    </div>
    <div class="credits">
        Qarshi 2024
    </div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.16.9/dist/xlsx.full.min.js"></script>
<script>
    $(document).ready(function() {
      $("#downloadExcel").click(function() {
        var wb = XLSX.utils.table_to_book(document.getElementById('myTable'), { sheet: "Jadval" });
        XLSX.writeFile(wb, 'jadval.xlsx');
      });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/report/moliya_search.blade.php ENDPATH**/ ?>