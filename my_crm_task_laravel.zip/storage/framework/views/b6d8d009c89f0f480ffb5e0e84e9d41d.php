<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruhlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Yangi guruh</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 class="card-title w-100 text-center">Yangi guruh haqida</h2>
                            <div class="row">
                                <div class="col-lg-6">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Yangi guruh:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['guruh_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Guruh narxi:</th>
                                            <td style="text-align:right;"><?php echo e(number_format($guruh['summa'], 0, '.', ' ')); ?> so'm</td>
                                        </tr>
                                        <tr>
                                            <th>Boshlanish vaqti:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['guruh_start']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tugash vaqti:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['guruh_end']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Darslar soni:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['dars_count']); ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-lg-6">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Hafta kuni:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['hafta_kun2']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Kurs:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['cours_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <th>O'qituvchi:</th>
                                            <td style="text-align:right;"><?php echo e($guruh['techer']); ?></td>
                                        </tr>
                                        <?php if($markaz==1): ?>
                                        <tr>
                                            <th>O'qituvchiga to'lov(%):</th>
                                            <td style="text-align:right;"><?php echo e($guruh['techer_foiz']); ?> %</td>
                                        </tr>
                                        <tr>
                                            <th>Meneger:</th>
                                            <td style="text-align:right;"><?php echo e(auth()->user()->email); ?></td>
                                        </tr>
                                        <?php elseif($markaz==2): ?>
                                        <tr>
                                            <th>O'qituvchiga to'lov:</th>
                                            <td style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</td>
                                        </tr>
                                        <tr>
                                            <th>Meneger:</th>
                                            <td style="text-align:right;"><?php echo e(auth()->user()->email); ?></td>
                                        </tr>
                                        <?php elseif($markaz==3): ?>
                                        <tr>
                                            <th>O'qituvchiga to'lov:</th>
                                            <td style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</td>
                                        </tr>
                                        <tr>
                                            <th>O'qituvchiga bonus:</th>
                                            <td style="text-align:right;"><?php echo e(number_format($guruh['techer_bonus'], 0, '.', ' ')); ?> so'm</td>
                                        </tr>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                            <form action="<?php echo e(route('meneger_groups_create_story_two')); ?>" method="post">
                                <?php echo csrf_field(); ?> 
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="room_id" class="my-2">Dars xonasi</label>
                                        <select name="room_id" id="room_id" required class="form-select">
                                            <option value="">Tanlang...</option>
                                            <?php $__currentLoopData = $xonalar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['room_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="dars_time" class="my-2">Dars vaqti</label>
                                        <select name="dars_time" id="dars_time" required class="form-select">
                                            <option value="">Oldin xonani tanlang</option>
                                        </select>
                                    </div>
                                    <script>
                                        $(document).ready(function() {
                                            $('#room_id').on('change', function() {
                                                var regionId = $(this).val();
                                                if (regionId) {
                                                    $.ajax({
                                                        url: '/meneger/groups/create/two/' + regionId,
                                                        type: 'GET',
                                                        dataType: 'json',
                                                        success: function(data) {
                                                            $('#dars_time').empty();
                                                            $('#dars_time').append('<option value="">Dars vaqtini tanlang</option>');
                                                            $.each(data, function(key, value) {
                                                                $('#dars_time').append('<option value="'+ value.time +'">'+ value.time +'</option>');
                                                            });
                                                        }
                                                    });
                                                } else {
                                                    $('#dars_time').empty();
                                                    $('#dars_time').append('<option value="">Siz tanlagan xonada barcha vaqtlar band</option>');
                                                }
                                            });
                                        });
                                    </script>
                                    
                                    <div class="col-lg-6 text-center mt-4">
                                        <a href="<?php echo e(route('meneger_groups_create')); ?>" class="btn btn-danger w-50">Bekor qilish</a>
                                    </div>
                                    <div class="col-lg-6 text-center mt-4">
                                        <button class="btn btn-primary w-50">Guruhni saqlash</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4">
                            <h2 class="card-title w-100 text-center">Dars kunlari</h2>
                            <table class="table table-bordered text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Dars kuni</th>
                                    <th>Hafta kuni</th>
                                </tr>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['data']); ?></td>
                                    <td><?php echo e($item['kun']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/create2.blade.php ENDPATH**/ ?>