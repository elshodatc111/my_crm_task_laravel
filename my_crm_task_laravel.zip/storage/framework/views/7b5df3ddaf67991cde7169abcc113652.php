<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruhlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Yangi guruh</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">

            <div class="row mb-2">
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups')); ?>" class="btn btn-secondary w-100">Guruhlar</a>
                </div>
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups_end')); ?>" class="btn btn-secondary w-100">Yakunlangan guruhlar</a>
                </div>
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups_create')); ?>" class="btn btn-primary w-100">Yangi guruh</a>
                </div>
            </div>
            <form action="<?php echo e(route('meneger_groups_create_story')); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title w-100 mb-0 pb-0">Yangi guruh haqida</h5>
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="guruh_name" class="my-2">Guruh nomi</label>
                                <input type="text" name="guruh_name" value="<?php echo e(old('guruh_name')); ?>" required class="form-control">
                                <label for="tulov_id" class="my-2">Guruhning narxi</label>
                                <select name="tulov_id" required class="form-select">
                                    <option value="">Tanlang...</option>
                                    <?php $__currentLoopData = $MarkazPaymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['id']); ?>"><?php echo e(number_format($item['summa'], 0, '.', ' ')); ?> so'm, Chegirma: <?php echo e(number_format($item['chegirma'], 0, '.', ' ')); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="dars_count" class="my-2">Darslar sonini kiriting ( Maksima darslar soni : 30 )</label>
                                <input type="number" value="<?php echo e(old('dars_count')); ?>" max=30 min=9 name="dars_count" required class="form-control">
                            </div>
                            <div class="col-lg-6">
                                <label for="guruh_start" class="my-2">Dars boshlanish sanasi</label>
                                <input type="date" name="guruh_start" value="<?php echo e(old('guruh_start')); ?>" required class="form-control">
                                <?php $__errorArgs = ['guruh_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger w-100" style="font-size:10px;">Darslar boshlanishi bugungi kun va keyingi kunlarni qabul qilinadi.</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="hafta_kun" class="my-2 w-100">Hafta kunlari</label>
                                <select name="hafta_kun" required class="form-select">
                                    <option value="">Tanlang...</option>
                                    <option value="toq_kun">Haftaning toq kunlari</option>
                                    <option value="juft_kun">Haftaning juft kunlari</option>
                                    <option value="har_kun">Har kuni</option>
                                </select>
                                <label for="cours_id" class="my-2">Guruh uchun kursni tanlang</label>
                                <select name="cours_id" required class="form-select">
                                    <option value="">Tanlang...</option>
                                    <?php $__currentLoopData = $Cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cours_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <label for="techer_id" class="my-2">Guruh uchun o'qituvchi tanlang</label>
                        <select name="techer_id" required class="form-select">
                            <option value="">Tanlang...</option>
                            <?php $__currentLoopData = $Techer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($Markaz == 1): ?>
                            <label for="techer_foiz" class="my-2">O'qituvchiga to'lov foizi(%)</label>
                            <input type="number" value="<?php echo e(old('techer_foiz')); ?>" name="techer_foiz" min="0" max="100" required class="form-control">
                        <?php elseif($Markaz == 2): ?>
                            <label for="techer_paymart" class="my-2">O'qituvchiga to'lov (Har bir talaba uchun)</label>
                            <input type="text" value="<?php echo e(old('techer_paymart')); ?>" name="techer_paymart" required class="form-control amount">
                        <?php else: ?>
                            <label for="techer_paymart" class="my-2">O'qituvchiga to'lov (Har bir talaba uchun)</label>
                            <input type="text" value="<?php echo e(old('techer_paymart')); ?>" name="techer_paymart" required class="form-control amount">
                            <label for="techer_bonus" class="my-2">O'qituvchiga bonus</label>
                            <input type="text" value="<?php echo e(old('techer_bonus')); ?>" name="techer_bonus" required class="form-control amount">
                        <?php endif; ?>
                        <div class="w-100 text-center mt-2">
                            <button type="submit" class="btn btn-primary w-50">Davom etish    </button>
                        </div>
                    </div>
                </div>
            </form>
        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/create.blade.php ENDPATH**/ ?>