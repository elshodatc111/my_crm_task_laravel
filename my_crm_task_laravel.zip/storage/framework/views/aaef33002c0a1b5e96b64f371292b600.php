<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruh</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_groups')); ?>">Guruhlar</a></li>
                    <li class="breadcrumb-item active">Guruhning davomi</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">      
                            <h5 class="card-title w-100 text-center mb-0">Yangi guruh haqida</h5>
                        </div>
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center"><?php echo e($guruh['guruh_name']); ?></h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Dars xonasi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['room']); ?></div>
                                <div class="col-6  mt-1"><b>Dars boshlandi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_start']); ?></div>
                                <div class="col-6  mt-1"><b>Dars tugadi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_end']); ?></div>
                                <div class="col-6  mt-1"><b>Darslar soni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_count']); ?></div>
                                <div class="col-6  mt-1"><b>Dars vaqti:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_time']); ?></div>
                                <div class="col-6  mt-1"><b>Hafta kuni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['hafta_kun']); ?></div>
                            </div>
                        </div>
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center">Guruh narxi: <?php echo e(number_format($guruh['summa'], 0, '.', ' ')); ?> so'm</h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Chegirma:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['chegirma'], 0, '.', ' ')); ?> so'm</div>  
                                <div class="col-6  mt-1"><b>Chegirma muddati:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['chegirma_time']); ?> kun</div>  
                                <div class="col-6  mt-1"><b>O'qituvchi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer']); ?></div>
                                <?php if($Markaz == 1): ?>
                                <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer_foiz']); ?>%</div>
                                <?php elseif($Markaz == 2): ?>
                                <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                <?php else: ?>
                                <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                <div class="col-6  mt-1"><b>Ish haqi bonus:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_bonus'], 0, '.', ' ')); ?> so'm</div>     
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title w-100 text-center">Dars Kunlari</h2>
                            <table class="table table-bordered text-center">
                                <tr>
                                    <th>#</th>
                                    <th>Dars kuni</th>
                                    <th>Hafta kuni</th>
                                </tr>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['data']); ?></td>
                                    <td><?php echo e($item['kun']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title w-100 text-center">Yangi guruhga o'tadigan talabalar</h2>
                            <form action="<?php echo e(route('meneger_groups_next_create_story_end')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <ul class="list-group">
                                    <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <input class="form-check-input me-1" type="checkbox" name="user<?php echo e($item['id']); ?>" value="<?php echo e($item['id']); ?>" aria-label="...">
                                        <?php echo e($item['name']); ?> <?php echo e($item['id']); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <button type="submit" class="btn btn-primary w-100 mt-2">Yangi guruhni saqlash</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/create_next_two.blade.php ENDPATH**/ ?>