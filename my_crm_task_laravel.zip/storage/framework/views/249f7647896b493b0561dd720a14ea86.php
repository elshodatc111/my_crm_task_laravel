<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruhlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Yakunlangan Guruhlar</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">

            <div class="row mb-2">
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups')); ?>" class="btn btn-secondary w-100">Guruhlar</a>
                </div>
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups_end')); ?>" class="btn btn-primary w-100">Yakunlangan guruhlar</a>
                </div>
                <div class="col-lg-4 my-lg-0 mt-2">
                    <a href="<?php echo e(route('meneger_groups_create')); ?>" class="btn btn-secondary w-100">Yangi guruh</a>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <h5 class="card-title w-100 text-center">Yakunlangan Guruhlar</h5>
                    <div class="table-responsive">
                        <table class="table text-center table-bordered" style="font-size: 12px;">
                            <thead>
                                <tr class="align-items-center">
                                    <th>#</th>
                                    <th>Guruh</th>
                                    <th>Boshlanish vaqti</th>
                                    <th>Yakunlanish vaqti</th>
                                    <th>Dars xonasi</th>
                                    <th>Dars vaqti</th>
                                    <th>Talabalar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $Guruh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td style="text-align:left;">
                                        <a href="<?php echo e(route('meneger_groups_show',$item['id'])); ?>"><b><?php echo e($item['guruh_name']); ?></b></a>
                                    </td>
                                    <td><?php echo e($item['guruh_start']); ?></td>
                                    <td><?php echo e($item['guruh_end']); ?></td>
                                    <td><?php echo e($item['room']); ?></td>
                                    <td><?php echo e($item['dars_time']); ?></td>
                                    <td><?php echo e($item['users']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan=7 class="text-center">Guruhlar mavjud emas.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/group_end.blade.php ENDPATH**/ ?>