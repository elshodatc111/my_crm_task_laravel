
<?php $__env->startSection('title', 'Statistka'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Statistka</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Statistka</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row mb-2">
                <div class="col-lg-3 mt-lg-0 mt-2">
                    <a href="<?php echo e(route('chart_days')); ?>" class="btn btn-primary w-100">Kunlik Statistika</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                    <a href="<?php echo e(route('chart_days_table')); ?>" class="btn btn-secondary w-100">Kunlik Jadval</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                    <a href="<?php echo e(route('chart_monch')); ?>" class="btn btn-secondary w-100">Oylik Statistika</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                    <a href="<?php echo e(route('chart_monch_table')); ?>" class="btn btn-secondary w-100">Oylik Jadval</a>
                </div>
            </div>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php elseif(Session::has('error')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Kunlik to'lovlar</h2>
                    <div id="daysPaymart"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#daysPaymart"), {
                            series: [{
                                name: "Naqt to'lovlar",
                                data: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['naqt']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Plastik to'lovlar",
                                data: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['plastik']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Payme to'lovlar",
                                data: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['payme']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Qaytarilgan to'lovlar",
                                data: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['qaytar']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Chegirmalar",
                                data: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['chegirma']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }],
                            chart: {type: 'bar',height: 400},
                            plotOptions: {bar: {horizontal: false,columnWidth: '55%',endingShape: 'rounded'},},
                            dataLabels: {enabled: false},
                            stroke: {show: true,width: 2,colors: ['transparent']},
                            xaxis: {categories: [
                                <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    "<?php echo e($item['data']); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],},
                            yaxis: {title: {text: "Kunlik to'lovlar"}},
                            fill: {opacity: 1},
                            tooltip: {y: {formatter: function(val) {return val + " so'm"}}}
                        }).render();
                        });
                    </script>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Kunlik moliya</h2>
                    <div id="kunlikMoliya"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#kunlikMoliya"), {
                            series: [{
                                name: "Kassadan Chiqim",
                                data: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['kassaChiqim']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Balansdan chiqim",
                                data: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['balansChiqim']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Kassadan Xarajat",
                                data: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['kassaXarajat']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Balansdan Xarajat",
                                data: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['balansXarajat']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "To'langan ish haqi",
                                data: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['ishHaqi']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }],
                            chart: {type: 'bar',height: 400},
                            plotOptions: {bar: {horizontal: false,columnWidth: '55%',endingShape: 'rounded'},},
                            dataLabels: {enabled: false},
                            stroke: {show: true,width: 2,colors: ['transparent']},
                            xaxis: {categories: [
                                    <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        "<?php echo e($item['data']); ?>",
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],
                            },
                            yaxis: {title: {text: "Kunlik Moliya"}},
                            fill: {opacity: 1},
                            tooltip: {y: {formatter: function(val) {return val + " so'm"}}}
                        }).render();
                        });
                    </script>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Kunlik tashriflar</h2>
                    <div id="daysVised"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#daysVised"), {
                            series: [{
                                name: "Yangi tashrif",
                                data: [
                                    <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['users']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "Guruhga biriktirildi",
                                data: [
                                    <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['guruh']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }, {
                                name: "To'lov qildi",
                                data: [
                                    <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($item['tulov']); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ]
                            }],
                            chart: {type: 'bar',height: 400},
                            plotOptions: {bar: {horizontal: false,columnWidth: '55%',endingShape: 'rounded'},},
                            dataLabels: {enabled: false},
                            stroke: {show: true, width: 2 ,colors: ['transparent']},
                            xaxis: {categories: [
                                    <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        "<?php echo e($item['data']); ?>",
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],},
                            yaxis: {title: {text: "Kunlik tashriflar"}},
                            fill: {opacity: 1},
                            tooltip: {y: {formatter: function(val) {return val + " ta"}}}
                        }).render();
                        });
                    </script>
                </div>
            </div>

        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/statistika/days.blade.php ENDPATH**/ ?>