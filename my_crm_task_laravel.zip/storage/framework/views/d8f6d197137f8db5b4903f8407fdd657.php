<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

<div class="pagetitle">
  <h1>O'qituvchi</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.techer')); ?>">O'qituvchlar</a></li>
      <li class="breadcrumb-item active">O'qituvchi</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">
<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('error')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-lg-8">      
      <div class="card" style="min-height: 300px;">
        <div class="card-body">
          <h5 class="card-title w-100 text-center"><?php echo e($User['name']); ?></h5>
          <div class="row">
            <div class="col-6  mt-1"><b>Telefon raqam:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['phone1']); ?></div>
            <div class="col-6  mt-1"><b>Telefon raqam:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['phone2']); ?></div>
            <div class="col-6  mt-1"><b>Manzil:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['addres']); ?></div>
            <div class="col-6  mt-1"><b>Tug'ilgan kun:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['tkun']); ?></div>
            <div class="col-6  mt-1"><b>Login:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['email']); ?></div>
            <div class="col-6  mt-1"><b>Ishga olindi:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['created_at']); ?></div>
            <div class="col-6  mt-1"><b>O'qituvchi haqida:</b></div>
            <div class="col-6" style="text-align:right;"><?php echo e($User['about']); ?></div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-4">      
      <div class="card" style="min-height: 300px;">
        <div class="card-body">
          <button class="btn btn-outline-primary w-100 mt-3" data-bs-toggle="modal" data-bs-target="#updatePassword">Parolni yangilash</button>
          <button class="btn btn-outline-primary w-100 mt-2" data-bs-toggle="modal" data-bs-target="#updateUser">Taxrirlash</button>
          <button class="btn btn-outline-primary w-100 mt-2" data-bs-toggle="modal" data-bs-target="#hodimPay">Ish haqi to'lash</button>
        </div>
      </div>
    </div>
  </div>
  <!--Hodimni parolini yangilash-->
  <div class="modal fade" id="updatePassword" tabindex="-1">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title w-100 text-center">Parolni yangilash</h5>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('meneger.techer_update_password')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($User->id); ?>">
            <div class="row">
              <div class="col-6">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
              </div>
              <div class="col-6">
                <button type="submit" class="btn btn-primary w-100">Yangilash</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!--Taxrirlash-->
  <div class="modal fade" id="updateUser" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title w-100 text-center">O'qituvchi ma`lumotlarini yangilash</h5>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('meneger.techer_update_store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($User->id); ?>">
            <label for="" class="mb-2">FIO</label>
            <input type="text" name="name" value="<?php echo e($User->name); ?>" required class="form-control">
            <label for="" class="my-2">Yashash manzili</label>
            <select name="addres" required class="form-select">
              <option value="">Tanlang</option>
              <?php $__currentLoopData = $MarkazAddres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item['addres']); ?>"><?php echo e($item['addres']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="" class="my-2">Tug'ilgan kuni</label>
            <input type="date" name="tkun" value="<?php echo e($User['tkun']); ?>" required class="form-control">
            <label for="" class="my-2">Telefon raqam</label>
            <input type="text" name="phone1" value="<?php echo e($User['phone1']); ?>" required class="form-control phone">
            <label for="" class="my-2">Qo'shimcha telefin raqam</label>
            <input type="text" name="phone2" value="<?php echo e($User['phone2']); ?>" required class="form-control phone">
            <label for="" class="my-2">O'qituvchi haqida</label>
            <textarea required class="form-control mb-2" name="about"><?php echo e($User['about']); ?></textarea>
            <div class="row">
              <div class="col-6">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
              </div>
              <div class="col-6">
                <button type="submit" class="btn btn-primary w-100">Yangilash</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!--Ish haqi to'lsh-->
  <div class="modal fade" id="hodimPay" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title w-100 text-center">O'qituvchi ish haqi to'lash</h5>
        </div>
        <div class="modal-body">
          <div class="row text-center">
            <div class="col-12">
              <b>Kassada mavjud</b>
            </div>
            <div class="col-6">
              <b>Naqt: </b><?php echo e(number_format($Kassa['kassa_naqt_ish_haqi_pedding'], 0, '.', ' ')); ?>

            </div>
            <div class="col-6">
              <b>Naqt: </b><?php echo e(number_format($Kassa['kassa_plastik_ish_haqi_pedding'], 0, '.', ' ')); ?>

            </div>
          </div>
          <form action="<?php echo e(route('meneger.techer_paymart')); ?>" method="post">
            <?php echo csrf_field(); ?> 
            <input type="hidden" name="user_id" value="<?php echo e($User['id']); ?>">
            <input type="hidden" name="Naqt" value="<?php echo e($Kassa['kassa_naqt_ish_haqi_pedding']); ?>">
            <input type="hidden" name="Plastik" value="<?php echo e($Kassa['kassa_plastik_ish_haqi_pedding']); ?>">
            <label for="summa" class="my-2">Ish haqi so'mmasi</label>
            <input type="text" name="summa" required class="form-control amount">
            <label for="type" class="my-2">To'lov turi</label>
            <select name="type" required class="form-select">
              <option value="">Tanlang</option>
              <option value="Naqt">Naqt</option>
              <option value="Plastik">Plastik</option>
            </select>
            <label for="" class="my-2">Guruhni tanlang</label>
            <select name="guruh_id" required class="form-select">
              <option value="">Tanlang</option>
              <?php $__currentLoopData = $TecherGrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item['guruh_id']); ?>" title="Hisoblandi: <?php echo e(number_format($item['techer_hisob'], 0, '.', ' ')); ?>, To'landi: <?php echo e(number_format($item['techer_tulandi'], 0, '.', ' ')); ?>, Qoldiq: <?php echo e(number_format($item['qoldiq'], 0, '.', ' ')); ?>"><?php echo e($item['guruh_name']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="comment" class="my-2">To'lov haqida</label>
            <textarea type="text" name="comment" required class="form-control mb-2"></textarea>
            <div class="row">
              <div class="col-6">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
              </div>
              <div class="col-6">
                <button type="submit" class="btn btn-primary w-100">To'lov</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title w-100 text-center">O'qituvchi guruhlari (Guruh yakunlangandan so'ng 45 kundan so'ng o'chiriladi.)</h5>
      <div class="table-responsive">
        <table class="table text-center table-bordered" style="font-size: 12px;">
          <thead>
            <tr class="align-items-center">
              <th>#</th>
              <th>Guruh</th>
              <th>Guruh holati</th>
              <th>Guruh talabalari</th>
              <th>Bonus talabalar</th>
              <th>Davomat</th>
              <th>Guruhga to'lovlar</th>
              <th>Hisoblandi</th>
              <th>To'langan</th>
              <th>Qoldiq</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $TecherGrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->index+1); ?></td>
              <td><a href="<?php echo e(route('meneger_groups_show', $item['guruh_id'])); ?>"><?php echo e($item['guruh_name']); ?></a></td>
              <td><?php echo e($item['guruh_status']); ?></td>
              <td><?php echo e($item['user_groups']); ?></td>
              <td><?php echo e($item['user_bonus']); ?></td>
              <td><?php echo e($item['user_davomat']); ?></td>
              <td><?php echo e(number_format($item['user_paymart'], 0, '.', ' ')); ?></td>
              <td><?php echo e(number_format($item['techer_hisob'], 0, '.', ' ')); ?></td>
              <td><?php echo e(number_format($item['techer_tulandi'], 0, '.', ' ')); ?></td>
              <td><?php echo e(number_format($item['qoldiq'], 0, '.', ' ')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan=10 class="text-center">O'qituvchi guruhlari mavjud emas.</td>
              </tr>
            <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <h5 class="card-title w-100 text-center">To'langan ish haqlari(oxirgi 45 kun)</h5>
      <div class="table-responsive">
        <table class="table text-center table-bordered" style="font-size: 12px;">
          <thead>
            <tr class="align-items-center">
              <th>#</th>
              <th>Guruh</th>
              <th>To'lov Summasi</th>
              <th>To'lov turi</th>
              <th>To'lov haqida</th>
              <th>To'lov vaqti</th>
              <th>Meneger</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $MarkazIshHaqi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->index+1); ?></td>
              <td><a href="<?php echo e(route('meneger_groups_show', $item['guruh'])); ?>"><?php echo e($item['guruh_name']); ?></a></td>
              <td><?php echo e(number_format($item['summa'], 0, '.', ' ')); ?></td>
              <td><?php echo e($item['type']); ?></td>
              <td><?php echo e($item['comment']); ?></td>
              <td><?php echo e($item['created_at']); ?></td>
              <td><?php echo e($item['meneger']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan=7 class="text-center">O'qituvchi uchun to'langan ish haqi mavjud emas.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

</main>

<footer id="footer" class="footer">
<div class="copyright">
  &copy; <strong><span>CodeStart</span></strong>. development center
</div>
<div class="credits">
  Qarshi 2024
</div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/hodim/techer_show.blade.php ENDPATH**/ ?>