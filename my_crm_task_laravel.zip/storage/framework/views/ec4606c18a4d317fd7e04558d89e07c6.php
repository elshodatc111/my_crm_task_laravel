<?php $__env->startSection('content'); ?>



  
  
<main id="main" class="main">

<div class="pagetitle">
  <h1>Tashriflar</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Bosh sahifa</a></li>
      <li class="breadcrumb-item active">Tashriflar</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">



  <div class="row mb-2">
    <div class="col-6 col-lg-3 mt-1">
      <a href="<?php echo e(route('admin.show',$id)); ?>" class="btn btn-secondary w-100">Markaz haqida</a>
    </div>
    <div class="col-6 col-lg-3 mt-1">
      <a href="<?php echo e(route('admin.show_setting',$id)); ?>" class="btn btn-primary w-100">Sozlamalar</a>
    </div>
    <div class="col-6 col-lg-3 mt-1">
      <a href="<?php echo e(route('admin.show_sms',$id)); ?>" class="btn btn-secondary w-100">SMS sozlamalari</a>
    </div>
    <div class="col-6 col-lg-3 mt-1">
      <a href="<?php echo e(route('admin.show_statistik',$id)); ?>" class="btn btn-secondary w-100">Statistika</a>
    </div>
  </div>

  <?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php elseif(Session::has('error')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle me-1"></i>
      <?php echo e(Session::get('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

      <div class="row">
        <div class="col-lg-6">
          <div class="card" style="min-height:400px">
            <div class="card-body mt-3">
              <form action="<?php echo e(route('admin.show_update',$id )); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <?php echo method_field('put'); ?>
                <label for="">O'quv markaz</label>
                <input type="text" name="name" value="<?php echo e($response['markaz']['name']); ?>" required class="form-control">
                <label for="">Drektor</label>
                <input type="text" name="drektor" value="<?php echo e($response['markaz']['drektor']); ?>" required class="form-control">
                <label for="">Telefon raqam</label>
                <input type="text" name="phone" value="<?php echo e($response['markaz']['phone']); ?>" required class="form-control">
                <label for="">Manzil</label>
                <input type="text" name="addres" value="<?php echo e($response['markaz']['addres']); ?>" required class="form-control">
                <label for="">Payme ID</label>
                <input type="text" name="payme_id" value="<?php echo e($response['markaz']['payme_id']); ?>" required class="form-control">
                <label for="">Payme ID</label>
                <input type="text" name="lessen_time" value="<?php echo e($response['markaz']['lessen_time']); ?>" required class="form-control">
                <label for="">Payme ID</label>
                <input type="text" name="paymart" value="<?php echo e($response['markaz']['paymart']); ?>" required class="form-control">
                <button type="submit" class="btn btn-primary w-100 mt-2">O'zgarishlarni saqlash</button>
              </form>
              <div class="w-100 text-center mt-2">
                <?php if($response['markaz']['status']=='true'): ?>
                <form action="<?php echo e(route('admin.show_update_lock')); ?>" method="post" style="display: inline;">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($id); ?>">
                  <button class="btn btn-danger">Bloklash</button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(route('admin.show_update_lock_block')); ?>" method="post" style="display: inline;">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($id); ?>">
                  <button class="btn btn-success">Aktivlashtirish</button>
                </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="card-title w-100 text-center">Xona Dars vaqtlari</div>
              <form action="<?php echo e(route('admin.generator')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <button class="btn btn-primary w-100 my-2">Dars vaqtlarini generatsiya qilish</button>
              </form>
              <table class="table text-center table-bordered" style="font-size: 12px;">
                  <thead>
                    <tr class="align-items-center">
                      <th>#</th>
                      <th>Darslar</th>
                      <th>Dars vaqti</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $response['generatsiya']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->index+1); ?></td>
                      <td><?php echo e($loop->index+1); ?>-dars</td>
                      <td><?php echo e($item['time']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
          </div>
        </div>
        
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="card-title w-100 text-center">Xizmat ko'rsatish manzillari</div>
              <table class="table text-center table-bordered" style="font-size: 12px;">
                <thead>
                  <tr class="align-items-center">
                    <th>#</th>
                    <th>Manzil</th>
                    <th>Yaratildi</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $MarkazAddres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($item['addres']); ?></td>
                    <td><?php echo e($item['created_at']); ?></td>
                    <td>
                      <form action="<?php echo e(route('admin.manzilDelete')); ?>" method="post" class="m-0">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                        <button type="submit" class="btn btn-danger p-1"><i class="bi bi-trash"></i></button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <hr>
              <form action="<?php echo e(route('admin.manzilCreate')); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <input type="hidden" name="markaz_id" value="<?php echo e($id); ?>">
                <label class="w-100 text-center">Yangi xizmar ko'rsatish manzili</label>
                <input type="text" name="addres" required class="form-control mb-2">
                <button class="btn btn-primary w-100">Yangi manzilni saqlash</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="card-title w-100 text-center">SMM sozlamalari</div>
              <table class="table text-center table-bordered" style="font-size: 12px;">
                <thead>
                  <tr class="align-items-center">
                    <th>#</th>
                    <th>SMM</th>
                    <th>Yaratildi</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $MarkazSmm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($item['smm']); ?></td>
                    <td><?php echo e($item['created_at']); ?></td>
                    <td>
                      <form action="<?php echo e(route('admin.smmDelete')); ?>" method="post" class="m-0">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                        <button type="submit" class="btn btn-danger p-1"><i class="bi bi-trash"></i></button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <hr>
              <form action="<?php echo e(route('admin.smmCreate')); ?>" method="post">
                <?php echo csrf_field(); ?> 
                <input type="hidden" name="markaz_id" value="<?php echo e($id); ?>">
                <label class="w-100 text-center">Yangi SMM</label>
                <input type="text" name="smm" required class="form-control mb-2">
                <button class="btn btn-primary w-100">Yangi SMMni saqlash</button>
              </form>
            </div>
          </div>
        </div>
        


        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="card-title w-100 text-center">Markaz kassa</div>
              <form action="<?php echo e(route('admin.kassaUpdate')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <label for="" class="my-2">Kassa Naqt</label>
                <input type="number" name="kassa_naqt" required value="<?php echo e($response['kassa']['kassa_naqt']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Naqt Chiqim Kutilmoqda</label>
                <input type="number" name="kassa_naqt_chiqim_pedding" required value="<?php echo e($response['kassa']['kassa_naqt_chiqim_pedding']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Naqt Xarajat Kutilmoqda</label>
                <input type="number" name="kassa_naqt_xarajat_pedding" required value="<?php echo e($response['kassa']['kassa_naqt_xarajat_pedding']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Naqt Ish Haqi Kutilmoqda</label>
                <input type="number" name="kassa_naqt_ish_haqi_pedding" required value="<?php echo e($response['kassa']['kassa_naqt_ish_haqi_pedding']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Plastik</label>
                <input type="number" name="kassa_plastik" required value="<?php echo e($response['kassa']['kassa_plastik']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Plastik Chiqim Kutilmoqda</label>
                <input type="number" name="kassa_plastik_chiqim_pedding" required value="<?php echo e($response['kassa']['kassa_plastik_chiqim_pedding']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Plastik Xarajat Kutilmoqda</label>
                <input type="number" name="kassa_plastik_xarajat_pedding" required value="<?php echo e($response['kassa']['kassa_plastik_xarajat_pedding']); ?>" class="form-control">
                <label for="" class="my-2">Kassa Plastik Ish haqi Kutilmoqda</label>
                <input type="number" name="kassa_plastik_ish_haqi_pedding" required value="<?php echo e($response['kassa']['kassa_plastik_ish_haqi_pedding']); ?>" class="form-control">
                <button class="btn btn-primary w-100 my-2">O'zgarishlarni saqlash</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="card-title w-100 text-center">Markaz Balans</div>
              <form action="<?php echo e(route('admin.balansUpdate')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <label for="" class="my-2">Balans Naqt</label>
                <input type="number" name="balans_naqt" required value="<?php echo e($response['balans']['balans_naqt']); ?>" class="form-control">
                <label for="" class="my-2">Balans Naqt Chiqim</label>
                <input type="number" name="balans_naqt_chiqim" required value="<?php echo e($response['balans']['balans_naqt_chiqim']); ?>" class="form-control">
                <label for="" class="my-2">Balans Naqt Xarajat</label>
                <input type="number" name="kassa_naqt_xarajat" required value="<?php echo e($response['balans']['kassa_naqt_xarajat']); ?>" class="form-control">
                <label for="" class="my-2">Balans Plastik</label>
                <input type="number" name="balans_plastik" required value="<?php echo e($response['balans']['balans_plastik']); ?>" class="form-control">
                <label for="" class="my-2">Balans Plastik Chiqim</label>
                <input type="number" name="balans_plastik_chiqim" required value="<?php echo e($response['balans']['balans_plastik_chiqim']); ?>" class="form-control">
                <label for="" class="my-2">Balans Plastik Xarajat</label>
                <input type="number" name="kassa_plastik_xarajat" required value="<?php echo e($response['balans']['kassa_plastik_xarajat']); ?>" class="form-control">
                <label for="" class="my-2">Balans Payme</label>
                <input type="number" name="balans_payme" required value="<?php echo e($response['balans']['balans_payme']); ?>" class="form-control">
                <label for="" class="my-2">Balans Payme Chiqim</label>
                <input type="number" name="balans_payme_chiqim" required value="<?php echo e($response['balans']['balans_payme_chiqim']); ?>" class="form-control">
                <button class="btn btn-primary w-100 my-2">O'zgarishlarni saqlash</button>
              </form>
            </div>
          </div>
        </div>
      </div>

</section>

</main>




  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; <strong><span>CodeStart</span></strong>. development center
    </div>
    <div class="credits">
      Qarshi 2024
    </div>
  </footer>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/admin/index_show_setting.blade.php ENDPATH**/ ?>