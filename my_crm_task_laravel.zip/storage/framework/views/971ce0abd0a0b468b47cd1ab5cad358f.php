<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Guruh</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_groups')); ?>">Guruhlar</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_groups_show',$guruh['id'])); ?>">Guruh</a></li>
                    <li class="breadcrumb-item active">Guruhning davomi</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">      
                            <h5 class="card-title w-100 text-center mb-0">Guruhni davom ettirish</h5>
                        </div>
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center"><?php echo e($guruh['guruh_name']); ?></h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Dars xonasi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['room_name']); ?></div>
                                <div class="col-6  mt-1"><b>Dars boshlandi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_start']); ?></div>
                                <div class="col-6  mt-1"><b>Dars tugadi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['guruh_end']); ?></div>
                                <div class="col-6  mt-1"><b>Darslar vaqti:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_time']); ?></div>
                                <div class="col-6  mt-1"><b>Darslar soni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['dars_count']); ?></div>
                                <div class="col-6  mt-1"><b>Hafta kuni:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['hafta_kun']); ?></div>
                            </div>
                        </div>
                        <div class="col-lg-6">      
                            <h5 class="card-title w-100 text-center">Guruh narxi: <?php echo e(number_format($guruh['paymart']['summa'], 0, '.', ' ')); ?> so'm</h5>
                            <div class="row">
                                <div class="col-6  mt-1"><b>Chegirma:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['paymart']['chegirma'], 0, '.', ' ')); ?> so'm</div>  
                                <div class="col-6  mt-1"><b>Chegirma muddati:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['paymart']['chegirma_time']); ?> kun</div>  
                                <div class="col-6  mt-1"><b>O'qituvchi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer']); ?></div>
                                <?php if($guruh['techer_tulov']==1): ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e($guruh['techer_foiz']); ?>%</div>
                                <?php elseif($guruh['techer_tulov']==2): ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                <?php else: ?>
                                    <div class="col-6  mt-1"><b>Ish haqi to'lov:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_paymart'], 0, '.', ' ')); ?> so'm</div>
                                    <div class="col-6  mt-1"><b>Ish haqi bonus:</b></div>
                                    <div class="col-6" style="text-align:right;"><?php echo e(number_format($guruh['techer_bonus'], 0, '.', ' ')); ?> so'm</div>
                                <?php endif; ?>
                                <div class="col-4  mt-1"><b>Meneger:</b></div>
                                <div class="col-8" style="text-align:right;"><?php echo e($guruh['meneger']); ?></div>
                                <div class="col-6  mt-1"><b>Guruh ochildi:</b></div>
                                <div class="col-6" style="text-align:right;"><?php echo e($guruh['created_at']); ?></div>        
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
            <div class="card">
                <div class="card-body">    
                    <h5 class="card-title w-100 text-center">Yangi guruh haqida</h5>
                    <form action="<?php echo e(route('meneger_groups_next_create_story')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <input type="hidden" name="id" value="<?php echo e($guruh['id']); ?>">
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="guruh_name" class="my-2">Yangi guruhning nomi</label>
                                <input type="text" name="guruh_name" value="<?php echo e(old('guruh_name')); ?>" required class="form-control">
                                <label for="guruh_start" class="my-2">Darslar boshlanish vaqti (<i class='text-danger' style="font-size:14px;"><?php echo e($guruh['guruh_end']); ?> dan kiyingi kunlar</i>)</label>
                                <input type="date" name="guruh_start" value="<?php echo e(old('guruh_start')); ?>" required class="form-control">
                                <?php $__errorArgs = ['guruh_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger w-100" style="font-size:10px;">Guruhni davom ettirish uchun <?php echo e($guruh['guruh_end']); ?> sanada keyingi kunlarda davom ettirish mumkun.</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="dars_count" class="my-2">Darslar sonini kiriting ( Maksima darslar soni : 30 )</label>
                                <input type="number" value="<?php echo e(old('dars_count')); ?>" max=30 min=9 name="dars_count" required class="form-control">                                
                                <label for="" class="my-2">Yangi guruh uchun kurs</label>
                                <select name="cours_id" required class="form-select">
                                    <option value="cours_id">Tanlang ... </option>
                                    <?php $__currentLoopData = $Cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['cours_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-lg-6">
                                <label for="tulov_id" class="my-2">Yangi guruh uchun to'lov summasi</label>
                                <select name="tulov_id" required class="form-select">
                                    <option value="">Tanlang ... </option>
                                    <?php $__currentLoopData = $MarkazPaymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>"><?php echo e(number_format($item['summa'], 0, '.', ' ')); ?> so'm, Chegirma: <?php echo e(number_format($item['chegirma'], 0, '.', ' ')); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="techer_id" class="my-2">Yangi guruh o'qituvchi</label>
                                <select name="techer_id" required class="form-select">
                                    <option value="">Tanlang ... </option>
                                    <?php $__currentLoopData = $Techer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($Markaz == 1): ?>
                                    <label for="techer_foiz" class="my-2">O'qituvchiga to'lov foizi(%)</label>
                                    <input type="number" value="<?php echo e(old('techer_foiz')); ?>" name="techer_foiz" min="0" max="100" required class="form-control">
                                <?php elseif($Markaz == 2): ?>
                                    <label for="techer_paymart" class="my-2">O'qituvchiga to'lov (Har bir talaba uchun)</label>
                                    <input type="text" value="<?php echo e(old('techer_paymart')); ?>" name="techer_paymart" required class="form-control amount">
                                <?php else: ?>
                                    <label for="techer_paymart" class="my-2">O'qituvchiga to'lov (Har bir talaba uchun)</label>
                                    <input type="text" value="<?php echo e(old('techer_paymart')); ?>" name="techer_paymart" required class="form-control amount">
                                    <label for="techer_bonus" class="my-2">O'qituvchiga bonus</label>
                                    <input type="text" value="<?php echo e(old('techer_bonus')); ?>" name="techer_bonus" required class="form-control amount">
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-12 text-center mt-2">
                            <button type="submit" class="btn btn-primary w-50">Davom etish</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </section>
    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/groups/create_next.blade.php ENDPATH**/ ?>