
<?php $__env->startSection('title', 'Dars jadval'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dars jadvali</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Dars jadvali</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row mb-2">
                <div class="col-lg-3 mt-lg-0 mt-3">
                <a href="<?php echo e(route('meneger.all_tashrif')); ?>" class="btn btn-secondary w-100">Tashriflar</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-3">
                <a href="<?php echo e(route('meneger.all_debet')); ?>" class="btn btn-secondary w-100">Qarzdorlar</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-3">
                <a href="<?php echo e(route('dars_jadval')); ?>" class="btn btn-primary w-100">Dars jadvali</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-3">
                <a href="<?php echo e(route('meneger.all_create')); ?>" class="btn btn-secondary w-100">Yangi tashrif</a>
                </div>
            </div>
            <?php $__currentLoopData = $Room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center"><?php echo e($item['room_name']); ?></h2>
                    <div class="table-responsive">
                        <table class="table text-center table-bordered" style="font-size: 12px;border:3px solid aqua">
                            <thead>
                                <tr>
                                    <th class="bg-primary text-white">Dars Vaqti</th>
                                    <?php $__currentLoopData = $item['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="bg-primary text-white"><?php echo e($item2); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $item['times']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyt => $item3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th class="bg-primary text-white"><?php echo e($item3); ?></th>
                                        <?php $__currentLoopData = $item['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item['about'][$keys][$keyt]['guruh_id'] == 'NULL'): ?>
                                            <td title="Xona bo'sh" class="bg-success text-white">--</td>
                                            <?php else: ?> 
                                            <td class="bg-white" title="<?php echo e($item['about'][$keys][$keyt]['guruh_name']); ?>"><a href="<?php echo e(route('meneger_groups_show',$item['about'][$keys][$keyt]['guruh_id'])); ?>" class="m-0 p-0 px-1 btn btn-danger">+</a></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/dars_jadval/jadval.blade.php ENDPATH**/ ?>