<?php $__env->startSection('title', 'Hisobot'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item active">Hisobot</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row mb-2">
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_student')); ?>" class="btn btn-secondary w-100">Talabalar</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_hodim')); ?>" class="btn btn-primary w-100">Hodimlar</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_moliya')); ?>" class="btn btn-secondary w-100">Moliya</a>
            </div>
            <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('report_active_user')); ?>" class="btn btn-secondary w-100">Aktiv talabalar</a>
            </div>
        </div>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h2 class="card-title w-100 text-center">Hodimlar</h2>
                <form action="<?php echo e(route('report_hodim_search')); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    <div class="row">
                        <div class="col-6">
                            <select name="type" required class="form-select">
                                <option value="">Tanlang</option>
                                <option value="allHodim">Barcha hodimlar</option>
                                <option value="allHodimTulov">Hodimlarga to'langan ish haqi</option>
                                <option value="allTecher">Barcha O'qituvchilar</option>
                                <option value="allTecherTulov">O'qituvchilarga  to'langan ish haqi</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-primary w-100">Filter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


        <div class="card">
            <div class="card-body">
                <h2 class="w-100 text-center card-title">
                    <?php if($type=='allHodim'): ?>
                        Barcha hodimlar
                    <?php elseif($type=='allHodimTulov'): ?>
                        Barcha hodimlarga to'langan ish haqi
                    <?php elseif($type=='allTecher'): ?>
                        Barcha o'qituvchilar
                    <?php elseif($type=='allTecherTulov'): ?>
                        Barcha o'qituvchilarga to'langan ish haqi
                    <?php endif; ?>
                </h2>
                <div class="w-100" style="text-align:right">
                    <button id="downloadExcel" class="btn btn-secondary" title="print excel"><i class="bi bi-printer"></i></button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="myTable" style="font-size:14px;border:1px solid #A5C8FD">
                        <head>
                        <?php if($type=='allHodim'): ?>
                            <tr>
                                <th>#</th>
                                <th>Hodim</th>
                                <th>Telefon raqami</th>
                                <th>Qo'shimcha telefon raqami</th>
                                <th>Yashash manzili</th>
                                <th>Tug'ilgan kuni</th>
                                <th>Ishga olini</th>
                                <th>Oxirgi yangilanish</th>
                                <th>Login</th>
                                <th>Hodim haqida</th>
                                <th>Lavozimi</th>
                                <th>Hodim holati</th>
                            </tr>
                        <?php elseif($type=='allHodimTulov'): ?>
                            <tr>
                                <th>#</th>
                                <th>Hodim</th>
                                <th>To'langan summa</th>
                                <th>To'lov turi</th>
                                <th>To'lov haqida</th>
                                <th>Meneger</th>
                                <th>To'lov qilindi</th>
                            </tr>
                        <?php elseif($type=='allTecher'): ?>
                            <tr>
                                <th>#</th>
                                <th>O'qituvchi</th>
                                <th>Telefon raqami</th>
                                <th>Qo'shimcha telefon raqami</th>
                                <th>Yashash manzili</th>
                                <th>Tug'ilgan kuni</th>
                                <th>Ishga olini</th>
                                <th>Oxirgi yangilanish</th>
                                <th>Login</th>
                                <th>O'qituvchi haqida</th>
                                <th>O'qituvchi holati</th>
                            </tr>
                        <?php elseif($type=='allTecherTulov'): ?>
                            <tr>
                                <th>#</th>
                                <th>O'qituvchi</th>
                                <th>To'langan summa</th>
                                <th>To'lov turi</th>
                                <th>To'longan guruh</th>
                                <th>To'lov haqida</th>
                                <th>Meneger</th>
                                <th>To'lov qilindi</th>
                            </tr>
                        <?php endif; ?>
                        </head>
                        <body>
                        <?php if($type=='allHodim'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td><?php echo e($item['phone1']); ?></td>
                                    <td><?php echo e($item['phone2']); ?></td>
                                    <td><?php echo e($item['addres']); ?></td>
                                    <td><?php echo e($item['tkun']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                    <td><?php echo e($item['email']); ?></td>
                                    <td><?php echo e($item['about']); ?></td>
                                    <td>
                                        <?php if($item['role_id']==2): ?>
                                            Drektor
                                        <?php elseif($item['role_id']==3): ?>
                                            Admin
                                        <?php elseif($item['role_id']==4): ?>
                                            Meneger
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item['status']=='true'): ?>
                                            Aktiv
                                        <?php else: ?> 
                                            Bloklangan
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=12 class="text-center">Hodimlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='allHodimTulov'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center">Hodimlarga to'langan ish haqi mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='allTecher'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td><?php echo e($item['phone1']); ?></td>
                                    <td><?php echo e($item['phone2']); ?></td>
                                    <td><?php echo e($item['addres']); ?></td>
                                    <td><?php echo e($item['tkun']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                    <td><?php echo e($item['email']); ?></td>
                                    <td><?php echo e($item['about']); ?></td>
                                    <td>
                                        <?php if($item['status']=='true'): ?>
                                            Aktiv
                                        <?php else: ?> 
                                            Bloklangan
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=11 class="text-center">O'qituvchilar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php elseif($type=='allTecherTulov'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $Search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td><?php echo e($item['summa']); ?></td>
                                    <td><?php echo e($item['type']); ?></td>
                                    <td><?php echo e($item['guruh_name']); ?></td>
                                    <td><?php echo e($item['comment']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=11 class="text-center">O'qituvchilarga to'langan ish haqi mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        <?php endif; ?>
                        </body>
                    </table>
                </div>
            </div>
        </div>
  
    </section>

</main>

<footer id="footer" class="footer">
    <div class="copyright">
        &copy; <strong><span>CodeStart</span></strong>. development center
    </div>
    <div class="credits">
        Qarshi 2024
    </div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.16.9/dist/xlsx.full.min.js"></script>
<script>
    $(document).ready(function() {
      $("#downloadExcel").click(function() {
        var wb = XLSX.utils.table_to_book(document.getElementById('myTable'), { sheet: "Jadval" });
        XLSX.writeFile(wb, 'jadval.xlsx');
      });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/report/hodimlar_search.blade.php ENDPATH**/ ?>