<table class="table text-center table-bordered" style="font-size: 12px;">
    <thead>
    <tr class="align-items-center">
        <th>#</th>
        <th>Talaba</th>
        <th>Telefon raqam</th>
        <th>Address</th>
        <th>Balans</th>
        <th>Ro'yhatdan o'tdi</th>
    </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td style="text-align:left;">
                <a href="<?php echo e(route('meneger.all_show', $user->id )); ?>"><b><?php echo e($user->name); ?></b></a>
            </td>
            <td><?php echo e($user->phone1); ?></td>
            <td><?php echo e($user->addres); ?></td>
            <td><?php echo e($user->balans); ?></td>
            <td><?php echo e($user->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td class="text-center" colspan=6>Talabalar mavjud emas.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

<div class="d-flex justify-content-center">
    <ul class="pagination">
        <?php if($users->onFirstPage()): ?>
            <li class="page-item disabled">
                <a class="page-link mx-1" style="padding: 10px 10px " href="#" tabindex="-1" aria-disabled="true"><i class="bi bi-caret-left"></i></a>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link mx-1" style="padding: 10px 10px " href="<?php echo e($users->previousPageUrl()); ?>"><i class="bi bi-caret-left"></i></a>
            </li>
        <?php endif; ?>
        <?php if($users->currentPage() > 3): ?>
            <li class="page-item">
                <a class="page-link mx-1" href="<?php echo e($users->url(1)); ?>">1</a>
            </li>
            <li class="page-item disabled">
                <span class="page-link mx-1">...</span>
            </li>
        <?php endif; ?>

        <?php $__currentLoopData = range(1, $users->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i >= $users->currentPage() - 2 && $i <= $users->currentPage() + 2): ?>
                <?php if($i == $users->currentPage()): ?>
                    <li class="page-item active" aria-current="page">
                        <a class="page-link mx-1" href="#"><?php echo e($i); ?></a>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link mx-1" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($users->currentPage() < $users->lastPage() - 2): ?>
            <li class="page-item disabled">
                <span class="page-link mx-1">...</span>
            </li>
            <li class="page-item">
                <a class="page-link mx-1" href="<?php echo e($users->url($users->lastPage())); ?>"><?php echo e($users->lastPage()); ?></a>
            </li>
        <?php endif; ?>

        <?php if($users->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link mx-1" style="padding:10px;" href="<?php echo e($users->nextPageUrl()); ?>"><i class="bi bi-caret-right"></i></a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <a class="page-link mx-1" href="#"  style="padding:10px;" tabindex="-1" aria-disabled="true"><i class="bi bi-caret-right"></i></a>
            </li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/students/pagination_data.blade.php ENDPATH**/ ?>