
<?php $__env->startSection('title', 'Balans'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

<div class="pagetitle">
  <h1>Form</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
      <li class="breadcrumb-item active">Arxiv</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php elseif(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-1"></i>
                <?php echo e(Session::get('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-3 col-6 pt-2">
            <a href="<?php echo e(route('form')); ?>" class="btn btn-secondary w-100">Form Murojat</a>
        </div>
        <div class="col-lg-3 col-6 pt-2">
            <a href="<?php echo e(route('form_techer')); ?>" class="btn btn-secondary w-100">Form Statistika</a>
        </div>
        <div class="col-lg-3 col-6 pt-2">
            <a href="<?php echo e(route('form_arxiv')); ?>" class="btn btn-primary w-100">Arxiv</a>
        </div>
        <div class="col-lg-3 col-6 pt-2">
            <a href="<?php echo e(route('form_url')); ?>" class="btn btn-secondary w-100">Form Manzil</a>
        </div>
    </div>
    <div class="card mt-3">
        <div class="card-body">
            <h2 class="card-title w-100 text-center">Form orqali kelib tushgan murojatlar arxivi</h2>
            <div class="table-responsive">
                <table class="table table-bordered text-center datatable" style="font-size:14px">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Type</th>
                            <th>FIO</th>
                            <th>Telefon raqami</th>
                            <th>Yashash manzili</th>
                            <th>Murojat vaqti</th>
                            <th>Holati</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $Form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td>
                                <?php if($item['type']=='User'): ?>
                                    <b class="p-0 m-0">Talaba</b>
                                <?php else: ?> 
                                    <b class="p-0 m-0">O'qituvchi</b>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:left"><?php echo e($item['name']); ?></td>
                            <td><?php echo e($item['phone1']); ?></td>
                            <td><?php echo e($item['addres']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['status']); ?></td>
                            <td>
                                <a href="<?php echo e(route('form_murojat_show',$item['id'])); ?>" class="btn btn-info py-1 px-1 text-white"><i class="bi bi-eye"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan=7 class="text-center">Aktiv murojatlar mavjud emas</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

</main>

<footer id="footer" class="footer">
<div class="copyright">
  &copy; <strong><span>CodeStart</span></strong>. development center
</div>
<div class="credits">
  Qarshi 2024
</div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/alert/form_arxiv.blade.php ENDPATH**/ ?>