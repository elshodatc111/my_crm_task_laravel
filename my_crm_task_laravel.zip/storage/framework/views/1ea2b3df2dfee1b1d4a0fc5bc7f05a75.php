
<?php $__env->startSection('title', 'Statistka'); ?>
<?php $__env->startSection('content'); ?>



    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Statistka</h1>
            <nav>
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item active">Statistka</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row mb-2">
                <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('chart_days')); ?>" class="btn btn-secondary w-100">Kunlik Statistika</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('chart_days_table')); ?>" class="btn btn-secondary w-100">Kunlik Jadval</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('chart_monch')); ?>" class="btn btn-primary w-100">Oylik Statistika</a>
                </div>
                <div class="col-lg-3 mt-lg-0 mt-2">
                <a href="<?php echo e(route('chart_monch_table')); ?>" class="btn btn-secondary w-100">Oylik Jadval</a>
                </div>
            </div>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php elseif(Session::has('error')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-1"></i>
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>




            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Oylik to'lovlar</h2>
                    <div id="tulovlar"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                            new ApexCharts(document.querySelector("#tulovlar"), {
                                series: [{
                                    name: "Naqt to'lovlar",
                                    data: [
                                        <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['naqt']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Plastik to'lovlar",
                                    data: [
                                        <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['plastik']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Payme to'lovlar",
                                    data: [
                                        <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['payme']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Qaytarilgan to'lovlar",
                                    data: [
                                        <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['qaytar']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Chegirmalar",
                                    data: [
                                        <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['chegirma']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                }],
                                chart: {height: 400,type: 'line',zoom: {enabled: false}},
                                dataLabels: {enabled: false},
                                stroke: {curve: 'straight'},
                                grid: {row: {colors: ['#FFA500', 'transparent'],opacity: 0.5},},
                                xaxis: {categories: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        "<?php echo e($item['data']); ?>",
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],}
                            }).render();
                        });
                    </script>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Oylik Moliya</h2>
                    <div id="moliya"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                            new ApexCharts(document.querySelector("#moliya"), {
                                series: [{
                                    name: "To'lovlar",
                                    data: [
                                        <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['tulovlar']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Xarajatlar",
                                    data: [
                                        <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['xarajatlar']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Ish haqi",
                                    data: [
                                        <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['ishHaqi']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Daromad",
                                    data: [
                                        <?php $__currentLoopData = $secont_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['daromad']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                }],
                                chart: {height: 400,type: 'line',zoom: {enabled: false}},
                                dataLabels: {enabled: false},
                                stroke: {curve: 'straight'},
                                grid: {row: {colors: ['#00ff00 ', 'transparent'],opacity: 0.5},},
                                xaxis: {categories: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        "<?php echo e($item['data']); ?>",
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],}
                            }).render();
                        });
                    </script>
                </div>
            </div>
 
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title w-100 text-center">Oylik Tashriflar</h2>
                    <div id="tashrif"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                            new ApexCharts(document.querySelector("#tashrif"), {
                                series: [{
                                    name: "Tashriflar",
                                    data: [
                                        <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['users']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "Guruhga biriktirildi",
                                    data: [
                                        <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['guruh']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                },{
                                    name: "To'lov qildi",
                                    data: [
                                        <?php $__currentLoopData = $there_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item['tulov']); ?>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    ]
                                }],
                                chart: {height: 400,type: 'line',zoom: {enabled: false}},
                                dataLabels: {enabled: false},
                                stroke: {curve: 'straight'},
                                grid: {row: {colors: ['#ff0000 ', 'transparent'],opacity: 0.5},},
                                xaxis: {categories: [
                                    <?php $__currentLoopData = $first_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        "<?php echo e($item['data']); ?>",
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],}
                            }).render();
                        });
                    </script>
                </div>
            </div>

        </section>

    </main>

    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>CodeStart</span></strong>. development center
        </div>
        <div class="credits">
            Qarshi 2024
        </div>
    </footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/statistika/month.blade.php ENDPATH**/ ?>