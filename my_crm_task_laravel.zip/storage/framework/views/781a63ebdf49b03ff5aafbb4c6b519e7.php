<?php $__env->startSection('title', 'Kirish'); ?>
<?php $__env->startSection('content'); ?>



<main id="main" class="main">

<div class="pagetitle">
  <h1>Sozlamalar</h1>
  <nav>
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('meneger.home')); ?>">Bosh sahifa</a></li>
      <li class="breadcrumb-item active">SMS sozlamalari</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">
  <div class="row mb-2">
    <div class="col-lg-3 mt-lg-0 mt-2">
      <a href="<?php echo e(route('meneger.rooms')); ?>" class="btn btn-secondary w-100">Xonalar</a>
    </div>
    <div class="col-lg-3 mt-lg-0 mt-2">
      <a href="<?php echo e(route('meneger.paymart')); ?>" class="btn btn-secondary w-100">To'lovlar</a>
    </div>
    <div class="col-lg-3 mt-lg-0 mt-2">
      <a href="<?php echo e(route('meneger.cours')); ?>" class="btn btn-secondary w-100">Kurslar</a>
    </div>
    <div class="col-lg-3 mt-lg-0 mt-2">
      <a href="<?php echo e(route('meneger.message')); ?>" class="btn btn-primary w-100">SMS</a>
    </div>
  </div>

  <div class="row">
    <div class="col-lg-6">
      <div class="card" style="min-height:220px">
        <div class="card-body">
          <h5 class="card-title w-100 text-center">SMS statistikasi</h5>
          <div class="row">
            <div class="col-6">
              <h5 class="w-100 text-center">Yuborilgan SMSlar</h5>
              <h3 class="w-100 text-center"><?php echo e($return['markaz']['count_sms']); ?></h3>
            </div>
            <div class="col-6">
              <h5 class="w-100 text-center">SMS uchun to'lovlar</h5>
              <h3 class="w-100 text-center"><?php echo e($return['markaz']['mavjud_sms']); ?></h3>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card" style="min-height:220px">
        <div class="card-body">
          <h5 class="card-title w-100 text-center">SMS Sozlamalar</h5>
          <form action="<?php echo e(route('meneger.message_update')); ?>" method="post">
            <?php echo csrf_field(); ?> 
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="new_user" <?php if($return['setting']['new_user']=='true'): ?> checked <?php endif; ?> >
              <label class="form-check-label" for="flexSwitchCheckChecked">Yangi tashriflar uchun sms yuborish</label>
            </div>
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="tkun" <?php if($return['setting']['tkun']=='true'): ?> checked <?php endif; ?> >
              <label class="form-check-label" for="flexSwitchCheckChecked">Tug'ilgan kunlar uchun sms yuborish</label>
            </div>
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" name="new_pay" <?php if($return['setting']['new_pay']=='true'): ?> checked <?php endif; ?> >
              <label class="form-check-label" for="flexSwitchCheckChecked">To'lovlar uchun sms yuborish</label>
            </div>
            <button class="btn btn-primary mt-2 w-100">O'zgarishlarni saqlash</button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title w-100 text-center">Xarid qilingan SMS paketlari</h5>
          <div class="table-responsive">
            <table class="table text-center table-bordered" style="font-size: 12px;">
              <thead>
                <tr class="align-items-center">
                  <th>#</th>
                  <th>SMS paket</th>
                  <th>To'lov summasi</th>
                  <th>Sotib olingan vaqt</th>
                  <th>Paket haqida</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $return['paket']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->index+1); ?></td>
                  <td><?php echo e($item['paket_soni']); ?></td>
                  <td><?php echo e(number_format($item['tulov'], 0, ',', ' ')); ?></td>
                  <td><?php echo e($item['created_at']); ?></td>
                  <td><?php echo e($item['description']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan=5 class="text-center">Xarid qilingan sms paketlari mavjud emas.</td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          
        </div>
      </div>
    </div>
  </div>
</section>

</main>


<footer id="footer" class="footer">
<div class="copyright">
  &copy; <strong><span>CodeStart</span></strong>. development center
</div>
<div class="credits">
  Qarshi 2024
</div>
</footer>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.meneger_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.meneger_src', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_crm_task_laravel\resources\views/meneger/setting/message.blade.php ENDPATH**/ ?>