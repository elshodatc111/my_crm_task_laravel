<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\UserBalans;
class UserBalansSeeder extends Seeder
{
    public function run(): void
    {
        UserBalans::create([
            'markaz_id' => 1,
            'user_id' => 6,
            'naqt' => 0,
            'plastik' => 0,
            'payme' => 0,
            'qaytarildi' => 0,
            'chegirma' => 0,
            'jarima' => 0,
        ]);
    }
}
