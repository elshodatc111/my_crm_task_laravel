@extends('layouts.meneger_src')
@section('content')
    <main>
        <div class="container">
            <section class="section error-404 min-vh-100 d-flex flex-column align-items-center justify-content-center">
                <h1>404</h1>
                <h2>Sizning loginingiz bloklangan. O'quv markaz bilan bog'laning.</h2>
            </section>
        </div>
    </main>
@endsection