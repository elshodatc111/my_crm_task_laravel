@extends('layouts.meneger_src')
@section('content')
    <main>
        <div class="container">
            <section class="section error-404 min-vh-100 d-flex flex-column align-items-center justify-content-center">
                <h1>404</h1>
                <h2 class="w-100 text-center">Tizim administrator tamonodan shartnoma shartlari bajarilmaganlik uchun <br>bloklangan. Administrator bilan bog'lanish.</h2>
            </section>
        </div>
    </main>
@endsection